import mongoose from "mongoose";
const AnalyticsSchema = new mongoose.Schema({
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: [true, 'User ID is required'],
    },
    campaignId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Campaign',
        required: [true, 'Campaign ID is required'],
    },
    activityType: {
        type: String,
        enum: ['login', 'interaction', 'win'],
        required: [true, 'Activity type is required'],
    },
    timestamp: {
        type: Date,
        default: Date.now,
    },
});

const Analytics = mongoose.model('Analytics', AnalyticsSchema);
export default Analytics