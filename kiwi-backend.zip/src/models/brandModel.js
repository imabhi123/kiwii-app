import mongoose from "mongoose";
const BrandSchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: [true, 'Brand name is required'],
            minlength: [2, 'Brand name must be at least 2 characters long'],
        },
        email: {
            type: String,
            required: [true, 'Email is required'],
            unique: true,
            match: [/.+@.+\..+/, 'Please enter a valid email'],
        },
        password: {
            type: String,
            required: [true, 'Password is required'],
            minlength: [8, 'Password must be at least 8 characters long'],
        },
        logoUrl: {
            type: String,
            match: [/^(https?|ftp):\/\/[^\s/$.?#].[^\s]*$/, 'Invalid URL'],
        }
    },
    {timestamps:true}
);

const Brand = mongoose.model('Brand', BrandSchema);

export default Brand;