import mongoose, { Schema } from "mongoose";
import jwt from "jsonwebtoken";
import bcrypt from "bcrypt";

const userSchema = new Schema(
  {
    email: {
      type: String,
      required: [true, 'Email is required'],
      unique: true,
      match: [/.+@.+\..+/, 'Please enter a valid email'],
    },
    role: {
      type: String,
      default: 'user'
    },
    mobile: {
      type: String,
      required: [true, 'Mobile number is required'],
      // match:[/^\d{10}$/, 'Please enter a valid mobile number'],
      default: '6283838383'
    },
    name: {
      type: String,
      required: true,
      default: 'Abhishek'
    },
    username: {
      type: String,
      required: [false, 'Username is not required'],
      minlength: [3, 'Username must be at least 3 characters long'],
    },
    password: {
      type: String,
      required: [true, 'Password is required'],
      minlength: [8, 'Password must be at least 8 characters long'],
    },
    status: {
      type: String,
      enum: ['active', 'inactive', 'suspended'],
      default: 'active',
    },
    registrationDate: {
      type: Date,
      default: Date.now,
    },
    country: {
      type: String,
      required: [true, 'Country is required'],
      default: 'India'
    },
    winHistory: {
      type: [
        {
          campaignId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Campaign',
            required: true,
          },
          wonAt: {
            type: Date,
            default: Date.now,
          },
        },
      ],
      default: [],
    },
    loginHistory: {
      type: [Date],
      default: [],
    },
    wins: {
      type: Number,
      default: 0,
      min: [0, 'Wins cannot be negative'],
    },
    redemptions: {
      type: Number,
      default: 0,
      min: [0, 'Redemptions cannot be negative'],
    },
    refreshToken: {
      type: String,
    },
  },
  {
    timestamps: true,
  }
);

// Hash the password before saving
userSchema.pre("save", async function (next) {
  if (!this.isModified("password")) return next();

  this.password = await bcrypt.hash(this.password, 10);
  next();
});

// Compare entered password with hashed password
userSchema.methods.isPasswordCorrect = async function (password) {
  return await bcrypt.compare(password, this.password);
};

// Generate an access token
userSchema.methods.generateAccessToken = function () {
  return jwt.sign(
    {
      _id: this._id,
      email: this.email,
      fullName: this.fullName,
    },
    process.env.ACCESS_TOKEN_SECRET,
    {
      expiresIn: process.env.ACCESS_TOKEN_EXPIRY,
    }
  );
};

// Generate a refresh token
userSchema.methods.generateRefreshToken = function () {
  return jwt.sign(
    {
      _id: this._id,
    },
    process.env.REFRESH_TOKEN_SECRET,
    {
      expiresIn: process.env.REFRESH_TOKEN_EXPIRY,
    }
  );
};

export const User = mongoose.model("User", userSchema);
