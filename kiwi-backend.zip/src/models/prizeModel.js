import mongoose from "mongoose";
const PrizeSchema = new mongoose.Schema({
    campaignId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Campaign',
        required: [true, 'Campaign ID is required'],
    },
    type: {
        type: String,
        enum: ['coupon', 'qr_code'],
        required: [true, 'Prize type is required'],
    },
    rules: {
        type: Map,
        of: String,
        validate: {
            validator: (value) => value && value.size > 0,
            message: 'Prize rules cannot be empty',
        },
    },
    redemptionStats: {
        redeemed: {
            type: Number,
            default: 0,
            min: [0, 'Redeemed count cannot be negative'],
        },
        total: {
            type: Number,
            default: 0,
            min: [0, 'Total count cannot be negative'],
        },
    },
    createdAt: {
        type: Date,
        default: Date.now,
    },
    updatedAt: {
        type: Date,
        default: Date.now,
    },
},{timestamps:true});

const Prize = mongoose.model('Prize', PrizeSchema);

export default Prize