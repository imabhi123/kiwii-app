// models/chat.js
import mongoose from 'mongoose';

const messageSchema = new mongoose.Schema({
  sender: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
    refPath: 'senderModel'
  },
  senderModel: {
    type: String,
    required: true,
    enum: ['User', 'Admin']
  },
  content: {
    type: String,
    required: true
  },
  timestamp: {
    type: Date,
    default: Date.now
  },
  read: {
    type: Boolean,
    default: false
  }
}, { timestamps: true });

const chatSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  admin: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Admin',
    default: null
  },
  status: {
    type: String,
    enum: ['pending', 'active', 'resolved'],
    default: 'pending'
  },
  messages: [messageSchema],
  lastMessage: {
    type: Date,
    default: Date.now
  },
  category: {
    type: String,
    required: true,
    enum: ['technical', 'billing', 'general', 'urgent']
  }
}, { timestamps: true });

export const Chat = mongoose.model('Chat', chatSchema);