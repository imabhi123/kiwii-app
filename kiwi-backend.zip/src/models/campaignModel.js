import mongoose from "mongoose";
const CampaignSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, 'Campaign name is required'],
        minlength: [3, 'Campaign name must be at least 3 characters long'],
    },
    brandId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Brand',
        required: [true, 'Brand ID is required'],
    },
    image: {
        type: String,
        match: [/^(https?|ftp):\/\/[^\s/$.?#].[^\s]*$/, 'Invalid URL'],
    },
    description: {
        type: String,
        maxlength: [500, 'Description cannot exceed 500 characters'],
    },
    parameters: {
        type: Map,
        of: String,
        validate: {
            validator: (value) => value && value.size > 0,
            message: 'Parameters cannot be empty',
        },
    },
    winPercentage:{
        type: Number,
        min: [0, 'Win percentage must be greater than 0'],
        default:2
    },
    engagementStats: {
        impressions: {
            type: Number,
            default: 0,
            min: [0, 'Impressions cannot be negative'],
        },
        interactions: {
            type: Number,
            default: 0,
            min: [0, 'Interactions cannot be negative'],
        },
    },
    status: {
        type: String,
        enum: ['active', 'completed', 'draft'],
        default: 'draft',
    },
    couponCode:{
        type:String,
        unique:true,
    }
},{timestamps:true});

const Campaign = mongoose.model('Campaign', CampaignSchema);
export default Campaign